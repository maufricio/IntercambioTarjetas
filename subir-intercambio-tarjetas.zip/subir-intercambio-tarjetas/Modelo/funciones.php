<?php
    require_once 'conexion.php';
    class functions{
        public function set_Tarjetas($nombreUsuario, $rubro, $subColeccion, $nombreTarjeta, $marca, $coleccion, $anio, $equipo, $imagen){
            try{
                $eConn = new Connection();
                $connPointer = $eConn -> get_conexion();
                $sql = "INSERT INTO tarjetas (usuario, rubro, subcoleccion, nombreTarjeta, marca, coleccion, anio, equipo, imagen) VALUES (:usuario, :rubro, :subcoleccion, :nombreTarjeta, :marca, :coleccion, :anio, :equipo, :imagen)";
                $declaration = $connPointer->prepare($sql);
                $declaration->bindParam(':usuario',$nombreUsuario);
                $declaration->bindParam(':rubro',$rubro);
                $declaration->bindParam(':subcoleccion',$subColeccion);
                $declaration->bindParam(':nombreTarjeta',$nombreTarjeta);
                $declaration->bindParam(':marca',$marca);
                $declaration->bindParam(':coleccion',$coleccion);
                $declaration->bindParam(':anio',$anio);
                $declaration->bindParam(':equipo',$equipo);
                $declaration->bindParam(':imagen',$imagen);
                if($declaration){
                    $declaration->execute();
                }else{
                    echo "--> Error al insertar la tarjeta <--";
                }
            }catch(Exception $b){
                $problem = 'Error encontrado :( : '.  $b->getMessage(). "\n";
                return $problem;
            }
        }
        public function cargarTarjetas($idUsuario){
            $rows = null;
            $modelo = new Connection();
            $conexion = $modelo-> get_conexion();
            $sql = "SELECT * FROM tarjetas WHERE usuario = $idUsuario";
            $statement = $conexion->prepare($sql);
            $statement->execute();
            while($resul = $statement->fetch()){
                $rows[] = $resul;
            }
            return $rows;
        }
        public function usuarios($username){
            $modelo = new Connection();
            $conexion = $modelo->get_conexion();
            $sql = "SELECT * FROM usuarios WHERE id_Usuario = :username";
            $statement = $conexion->prepare($sql);
            $statement->bindParam("username", $username);
            $statement->execute();
            while($resul = $statement->fetch(PDO::FETCH_ASSOC)){
                $rows[] = $resul;
            }
            return $rows;
        }


        public function getIdUsuario($username){
            try{
                $modelo = new Connection();
                $conexion = $modelo->get_conexion();
                $stmt = $conexion->prepare("SELECT id_Usuario FROM usuarios WHERE nombreUsuario=:username");
                $stmt->bindParam("username",$username, PDO::PARAM_STR);//always replace the value in function parameter
                $stmt->execute();
                $count = $stmt->rowCount();
                $data = $stmt->fetch();
                if($count){
                    $id = $data['id_Usuario']; //storing user session value
                }else{
                    return false; 
                }
                return $id;
            }catch(PDOException $e){
                echo '{"error":{"text":'.$e->getMessage().'}}';
            }
        
            
        }


        public function usuariosAll(){
            $modelo = new Connection();
            $conexion = $modelo->get_conexion();
            $sql = "SELECT * FROM usuarios";
            $statement = $conexion->prepare($sql);
            $statement->execute();
            while($resul = $statement->fetch(PDO::FETCH_ASSOC)){
                $rows[] = $resul;
            }
            return $rows;
        }
        public function tarjetaEspecifica($idTarjeta){
            $rows = null;
            $modelo = new Connection();
            $conexion = $modelo-> get_conexion();
            $sql = "SELECT * FROM tarjetas WHERE idTarjeta = $idTarjeta";
            $statement = $conexion->prepare($sql);
            $statement->execute();
            while($resul = $statement->fetch()){
                $rows[] = $resul;
            }
            return $rows;
        }
        public function eliminarTarjeta($idTarjeta){
            try{
                $rows = null;
                $modelo = new Connection();
                $conexion = $modelo-> get_conexion();
                $sql = "DELETE FROM tarjetas WHERE idTarjeta = :idTarjeta";
                $statement = $conexion->prepare($sql);
                $statement->bindParam('idTarjeta', $idTarjeta);
                if($statement){
                    $statement->execute();
                    echo "Intercambiado exitosamente!";
                }else{
                    echo "No se ha podido intercambiar";
                }
            }catch(PDOException $e){
                $problem = 'Error encontrado :( : '.  $e->getMessage(). "\n";
                return $problem;
            }
        }

         /*login*/
         public function userLogin($username){
            try{
                $modelo = new Connection();
                $db = $modelo->get_conexion();
                $stmt = $db->prepare("SELECT id_Usuario FROM usuarios WHERE nombreUsuario=:username");
                $stmt->bindParam("username",$username,PDO::PARAM_STR);//variable que se reemplaza como parametro de funcion
                $stmt->execute();
                $count = $stmt->rowCount();//Usuario encontrado, contado como encontrado una unica vez
                $data = $stmt->fetch();//Informacion del usuario encontrado
                $db = null; //Se rompe la conexion con base de datos
                if($count){
                    session_start();
                    $_SESSION['id_Usuario'] = $data['id_Usuario']; //almacenando la sesion del usuario, como tipo SESSION
                    return true;
                }else{
                    return false; 
                }
            }catch(PDOException $e){
                echo '{"error":{"text":'.$e->getMessage().'}}';
            }
        }

        /*Register*/
        public function userRegistration($firstName, $lastName, $password, $email){
            try{
                $modelo = new Connection();
                $db = $modelo->get_conexion();
                $stmt = $db->prepare("INSERT INTO usuarios (nombreUsuario, apellidoUsuario, password, email) VALUES (:nombreUsuario, :apellidoUsuario, :password, :email)");
                $stmt->bindParam("nombreUsuario",$firstName,PDO::PARAM_STR);
                $stmt->bindParam("apellidoUsuario",$lastName,PDO::PARAM_STR);
                $stmt->bindParam("password",$password,PDO::PARAM_STR);
                $stmt->bindParam("email",$email,PDO::PARAM_STR);
                if($stmt){
                    $stmt->execute();
                    echo "Usuario registrado existosamente";
                }else{
                    echo "--> Error al registrar usuario nuevo <--";
                }
            }catch(PDOException $e){//Se define la constante e de tipo PDOException
                echo '{"error":{"text":'.$e->getMessage().'}}';
            }
        }
    }