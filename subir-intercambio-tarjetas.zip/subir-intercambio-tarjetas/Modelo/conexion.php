<?php
    define("URL_FILE", "http://localhost/BeondPlatform/subir-intercambio-tarjetas/");
    class Connection{
        public function get_conexion(){
            try{
                $dbname = "beondplatform";
                $username = "root";
                $password = null;
                $host = "localhost";
                $conexion = new PDO("mysql:host=$host;dbname=$dbname", $username,$password);
                return $conexion;
            }catch(PDOException $e){
                $error = 'Error encontrado en conexión de Base de datos :( : '.  $e->getMessage(). "\n";
                return $error;
            }
    }
}
?>