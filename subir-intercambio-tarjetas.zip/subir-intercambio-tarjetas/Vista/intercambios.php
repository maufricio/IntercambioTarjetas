<?php 

require_once '../Modelo/funciones.php';
require_once '../Controlador/cargarTarjetas.php';
require_once '../Controlador/cargarUsuario.php';
require_once '../Controlador/session.php';
require_once '../Controlador/insertarIntercambio.php';

    $session_uid=session();
    $message = null;
    $aviso = '';
    @$submit= $_POST['submit'];
    //PENDIENTE LA IMAGEN
    @$nombreUsuario = obtenerUsuario($session_uid);
    @$rubro = $_POST['rubro'];
    @$subColeccion = $_POST['subColeccion'];
    @$nombreTarjeta = $_POST['nombreTarjeta'];
    @$marca = $_POST['marca'];
    @$coleccion = $_POST['coleccion'];
    @$anio = $_POST['anio'];
    @$equipo = $_POST['equipo'];
    @$imagen = $_FILES['imagen']['name'];
    if(isset($submit)){
        if(strlen($rubro) > 0 && strlen($subColeccion) > 0 && strlen($nombreTarjeta) > 0 && strlen($marca) > 0 
        && strlen($coleccion) > 0 && strlen($anio) > 0 && strlen($equipo) > 0 && isset($imagen) && $imagen != ""){ 
            if($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)){
                //print_r($_FILES);
                $tipo = $_FILES['imagen']['type'];
             
                    $check = @getimagesize($_FILES['imagen']['tmp_name']);
                    if($check !== false){
                        $carpeta_destino = 'C:/xampp/htdocs/BeondPlatform/subir-intercambio-tarjetas/fotos/';
                        $archivo_subir = $carpeta_destino . $_FILES['imagen']['name'];
                        move_uploaded_file($_FILES['imagen']['tmp_name'], $archivo_subir);
                        $functions = new functions();
                        $message = $functions->set_Tarjetas($nombreUsuario, $rubro, $subColeccion, $nombreTarjeta, $marca, $coleccion, $anio, $equipo, $imagen);
                        $aviso = "<div id='contenedorAviso'><p style='color:green; font-weight:800;'>SE REGISTRÓ EXITOSAMENTE</p><input type='submit' name='closeAviso' id='closeAviso' value='X'></div>";
                    }
            }
        }else{
            $message = "<div id='contenedorAviso'><p style='color:red; font-weight:800;'>INGRESE LOS DATOS DE LA TARJETA</p><input type='submit' name='closeAviso' id='closeAviso' value='X'></div>";
        }
    }
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingresar Cartas | Outta Series</title>
    <link rel="stylesheet" href="../Estilos/estilo-perfil.css"/>
    <link href="perfil.html" rel="import" />
    <link rel="shortcut icon" href="../Imagenes/OuttaSeriesLogoBlack.png" />
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
</head>
<body>

<div id="navegation-bar">
        <nav>
            <ul>
            <li><a href="../../Inicio-Beond/inicioBeond.html">INICIO</a></li>
                <li><a href="intercambios.php">INTERCAMBIOS</a></li>
                <li><a href="#">TIENDA</a></li>
                <a href="#"><img src="../Imagenes/OuttaSeriesLogoRed.png" alt="logo"></a>
                <li><a href="#">SUBASTAS</a></li>
                <li><a href="#">FOROS</a></li>
                <li><a href="#">MI CUENTA</a></li>

            </ul>
        </nav>
</div>    
 <section id="ingresoTarjetas">
        <div id="formulario">
            <h1>INGRESAR NUEVAS CARTAS</h1>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post" enctype="multipart/form-data">
           
            <div id="imagen-container">
            <div id="imagen-formulario-div">
           
                <input type="file" name="imagen" id="imagen-formulario" placeholder="Cargar Imagen" accept=".jpg, .png, .jpeg" aria-label="Archivo">
            </div>
            <p>Tamaño recomendado para subir tarjetas (341x480)</p>
            <div id="imagePreview">
           
            </div>
           
            </div>
           
                <div id="controls">


             <div id="controls-row-1">
                <div id="nombreUsuario-div">
                <label>NOMBRE DEL QUE INGRESA</label> <br>
                <input type="text" name="nombreUsuario" class="nombreUsuario" value="<?php echo obtenerNombreUsuario($session_uid);?>" readonly>
                </div>
                <div id="rubro-div">
                <label>RUBRO</label> <br>
                <select name="rubro" id="subColeccion">
                <option value="seleccionar" selected disabled>--SELECCIONAR--</option>
                    <option value="NBA DUNK">NBA DUNK</option>
                    <option value="opcion2">Opcion 2</option>
                    <option value="opcion3">Opcion 3</option>
                    <option value="opcion4">Opcion 4</option>
                    <option value="opcion5">Opcion 5</option>
                </select>
                </div>
                <div id="subColeccion-div">
                <label>SUB-COLECCIÓN</label> <br>
                <select name="subColeccion" id="subColeccion">
                <option value="seleccionar" selected disabled>--SELECCIONAR--</option>
                    <option value="NET MARVELS">NET MARVELS</option>
                    <option value="opcion2">Opcion 2</option>
                    <option value="opcion3">Opcion 3</option>
                    <option value="opcion4">Opcion 4</option>
                    <option value="opcion5">Opcion 5</option>
                </select>
                </div>
                <div id="nombreTarjeta-div">
                    <label>NOMBRE TARJETA</label> <br>
                    <input type="text" name="nombreTarjeta" class="nombreTarjeta" value="<?php  if(isset($_POST['nombreTarjeta'])){ echo $_POST['nombreTarjeta'];} ?>" autocomplete="off">
                </div>
            </div>


        <div id="controls-row-2">
            <div id="subColeccion-div">
                    <label>MARCA</label> <br>
                    <select name="marca" id="subColeccion">
                        <option value="seleccionar" selected disabled>--SELECCIONAR--</option>
                        <option value="PANINI">PANINI</option>
                        <option value="opcion2">Opcion 2</option>
                        <option value="opcion3">Opcion 3</option>
                        <option value="opcion4">Opcion 4</option>
                        <option value="opcion5">Opcion 5</option>
                    </select>
                </div>
                <div id="subColeccion-div">
                    <label>COLECCIÓN</label> <br>
                    <select name="coleccion" id="subColeccion">
                    <option value="seleccionar" selected disabled>--SELECCIONAR--</option>
                        <option value="DONRUSS 2020">DONRUSS 2020</option>
                        <option value="opcion2">Opcion 2</option>
                        <option value="opcion3">Opcion 3</option>
                        <option value="opcion4">Opcion 4</option>
                        <option value="opcion5">Opcion 5</option>
                    </select>
                </div>
                <div id="subColeccion-div">
                    <label>AÑO</label> <br>
                    <select name="anio" id="subColeccion">
                    <option value="seleccionar" selected disabled>--SELECCIONAR--</option>
                        <option value="2021">2021</option>
                        <option value="2020">2020</option>
                        <option value="2019">2019</option>
                        <option value="2018">2018</option>
                         <option value="2017">2017</option>
                        <option value="2016">2016</option>
                        <option value="2015">2015</option>
                        <option value="2014">2014</option>
                        <option value="2013">2013</option>
                        <option value="2012">2012</option>
                        <option value="2011">2011</option>
                        <option value="2010">2010</option>
                    </select>
                </div>
                    <div id="nombreTarjeta-div">
                        <label>EQUIPO</label> <br>
                        <input type="text" name="equipo" class="equipo" value="<?php if(isset($_POST['equipo'])){ echo $_POST['equipo'];} ?>"autocomplete="off">
                    </div>
                </div>

            <div id="controls-buttons">
                
                <input type="submit" name="submit" class="submit" value="SUBIR AL SISTEMA">
                <a href="#miModal"><abbr title="Ayuda"><img src="../Imagenes/admiracion.png" class="icono-admiracion" alt=""></abbr></a>
<div id="miModal" class="modal">
  <div class="modal-contenido">
    <a href="#">X</a>
    <div class="word">
        <span>H</span>
        <span>O</span>
        <span>L</span>
        <span>A</span>
        <span>!</span>
        <img src="../Imagenes/OuttaSeriesLogoRed.png" class="iconoModal">
    </div>
    

    <p><strong>Usuario de Outta Series,</strong></p><br>
    <div id="partModal1">
        <div id="txtModal1">
             <p>Sabrás... En este apartado es la zona vital de la plataforma. Por tanto es importante
                 que conozcas cuál es la utilidad de la misma. Además de ser una plataforma en donde puedes interactuar con diferentes 
                 personas, puedes mantener tu perfil en la mejor estabilidad y saludable; te enseñaremos cómo, vamos!
             </p>
        </div>
        <div class="imgModal1">
            <img src="../Imagenes/manWorking.svg" class ="manWorkingModal1"alt="">
        </div>
    </div>

    <div id="partModal2">
    <div id="txtModal2">
        <p>
        1. El espacio asignado en el apartado es correspondiente al ingreso de tarjetas de colección.</p>
             <img src="../Imagenes/paso1.png" class="paso1Modal" alt="">
             <p>
        2. Debes cargar una imagen que sea estrictamente al tema, es decir una imagen con respecto a una tarjeta de colección.</p>
        <img src="../Imagenes/paso2.png" class="paso2Modal" alt="">
        <p>3. Tu usuario será tomado como identificador de la carta de la quien la subió.</p>
        <img src="../Imagenes/paso3.png" class="paso3Modal" alt="">
        <p>4. La carta debe pertenecer a un rubro en específico, es decir, qué es lo que se colecciona.</p>
        <img src="../Imagenes/paso4.png" class="paso3Modal" alt="">
        <p>5. La subcolección de la carta significa la temporada de la misma.</p>
        <img src="../Imagenes/paso5.png" class="paso3Modal" alt="">
        <p>6. La carta debe contener un nombre que la identifique, dos tarjetas no podrán contener el mismo nombre.</p>
        <img src="../Imagenes/paso6.png" class="paso3Modal" alt="">
        <p>7. La carta debe ser perteneciente a una de las marcas cromáticas de dichas colecciones, se debe escoger del desplegable.</p>
        <img src="../Imagenes/paso7..png" class="paso3Modal" alt="">
        <p>8. La carta pertenece al nombre de la colección existente para dicha colección.</p>
        <img src="../Imagenes/paso8.png" class="paso3Modal" alt="">
        <p>9. La carta pertenece al año de salida de estreno de la misma.</p>
        <img src="../Imagenes/paso9.png" class="paso3Modal" alt="">
        <p>10. La carta pertenece a un equipo de juego que el personaje de la carta aparece, en caso contrario si no lo posee dictaminar "personaje singular"</p>
        <img src="../Imagenes/paso10.png" class="paso3Modal" alt="">
        </div>
    </div>
    
    
  </div>  
</div>
              
            </div>
                </div>
                
                    <div id="error-formulario"><?php echo $message; ?> </div>
                    <div id="error-formulario"><?php echo $aviso; ?> </div>
                
                </form>
            </div>
</section>

<section class="arrowDownContainer">
    
    <a href="#menuContainer"><abbr title="Deslizar hacia abajo"><img src="../Imagenes/arrowDown_adobespark.png" id="arrowDown" alt="Hacia Abajo"></abbr></a>
</section>
    <div class="menuContainer" id="menuContainer"></div>
    <div id="tarjetasContenedor">
    <div id="title-container-insertedCards">
            <h3 class="titulo-tarjetasInsertadas">Tarjetas del Usuario <?php  echo obtenerNombreUsuario($session_uid); ?></h3>
        </div>
        <div class="container">
        <?php cargar($nombreUsuario);?>
        </div>
    </div>
    

    <div id="intercambioTarjetas" class="intercambioModal">
        <div class="intercambio-contenido">
            <h2 class="titleIntercambioModal">Intercambiar Tarjeta con otros usuarios</h2>
        <img src="../Imagenes/OuttaSeriesLogoRed.png" class="intercambioModalImagen">
            <a href="#">X</a>

        
        <section class="mostradorTarjetaModal">
            <?php  
           @$nombreDestinatarioTarjeta = $_POST['txtNombreDestino'];
                $numeroTarjeta = cargarIDCard($nombreUsuario);
                echo loadSpecificCard($numeroTarjeta);
                echo loadSpecificName($numeroTarjeta);
                echo loadSpecificEquipo($numeroTarjeta);
                echo loadSpecificYear($numeroTarjeta);
            ?>
        </section>

        <div class="usuariosDisponiblesModal">
            <h4 class="titleListUsuariosModal">Usuarios Disponibles de Intercambio</h4>
            <?php echo obtenerUsuarioAll($numeroTarjeta); ?>
            <form action="../Controlador/eliminarTarjeta.php" method="POST">
            <div id="usuarioDestinatarioModal">
                <p style="font-size:13px;">Nombre de usuario a intercambiar:</p>
                <br><input type='text' name='txtNombreDestino' id='txtNombreDestino' class='txtNombreDestino' placeholder="Usuario Destino" autocomplete="off">
                <input type='submit' name='btnIntercambioModal' id='btnIntercambioModal' class='btnIntercambioModal' value='INTERCAMBIAR TARJETA'>
            </div>

            </form>
        </div>



        </div>
    </div>


<script src="../JavaScript/animacionesCartas.js"></script>
<script>
const spans = document.querySelectorAll('.word span');

spans.forEach((span, idx) => {
    span.addEventListener('click', (e) => {
        e.target.classList.add('active');
    });
    span.addEventListener('animationend', (e) => {
        e.target.classList.remove('active');
    });
    
    // Initial animation
    setTimeout(() => {
        span.classList.add('active');
    }, 750 * (idx+1))
});
</script>
</body>
</html>