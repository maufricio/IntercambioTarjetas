<?php
    require_once '../Modelo/conexion.php';
    require_once '../Modelo/funciones.php';
    require_once '../Controlador/login.php';
    
    $errorMsgReg= '';
    $errorMsgLogin = '';

    if(!empty($_POST['btnEnviarUsuario'])){
        $nombreUsuario = $_POST['nombreUsuarioRegistrado'];
        if(strlen(trim($nombreUsuario)) > 0){
            $errorMsgLogin = login($nombreUsuario);
        }else{
            $errorMsgLogin = "Por favor llene los campos";
        }
    }

    if(!empty($_POST['btnRegistrar'])) {
        $nombres = $_POST['nombres'];
        $apellidos = $_POST['apellidos'];
        $pass = $_POST['password'];
        $email = $_POST['email'];
        if(strlen(trim($nombres)) > 0 && strlen(trim($apellidos)) > 0 && strlen(trim($pass)) > 0 && strlen(trim($email)) > 0 ){
            $reg = new functions();
            $funcReg = $reg->userRegistration($nombres, $apellidos, $pass, $email);
            $errorMsgReg = $funcReg;
        }else{
            $errorMsgReg = "El usuario no ha podido ser registrado existosamente.";
        }
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios Beond | Outta Series</title>
    <link rel="stylesheet" href="../Estilos/estilousuarios.css">
</head>
<body>
<h1>Usuarios Beond</h1>
<div id="usuariosBeond">
   
<div id="iniciarsesion">
    <form action = "<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="POST">
        <h3>Inicio de sesión - Beond Platform</h3>
        <input type="text" name="nombreUsuarioRegistrado" id="nombreUsuarioRegistrado" placeholder="Nombre Usuario">
        <input type="submit" name="btnEnviarUsuario" id="btnEnviarUsuario" value="Confirmar">
        <div id="error-sesion"><?php echo $errorMsgLogin; ?></div>
    </form>
    </div>
   

    <div id="registrarusuario">
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method ="POST">
        <h3>Registros de usuarios - Beond Platform</h3>
        <input type="text" name="nombres" id="nombres" placeholder="Nombre Usuario">
        <input type="text" name="apellidos" id="apellidos" placeholder="Apellidos Usuario">
        <input type="password" name="password" id="password" placeholder="Contraseña">
        <input type="email" name="email" id="email" placeholder="Correo Electronico">
        <input type="submit" name="btnRegistrar" id="btnRegistrar" value="Registrar Usuario">
        <div id="error-sesion"><?php echo $errorMsgReg; ?></div>
    </form>
    </div>
   
</div>
   
</body>
</html>