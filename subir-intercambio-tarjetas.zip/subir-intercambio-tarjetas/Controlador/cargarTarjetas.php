<?php
 require_once '../Modelo/conexion.php';
 require_once '../Modelo/funciones.php';


function cargar($idUsuario){
    $functions = new functions();
    $filas = $functions->cargarTarjetas($idUsuario);
    if(is_object($filas) || is_array($filas)){
        foreach ($filas as $fila){
          
            echo "<div class='card'>";
            echo "<div class='imgBx'>";
            echo "<img class='imagenCargada' src='../fotos/".$fila['imagen']."'>";
            echo "</div>";
            echo "<div class='content'>";
            echo "<h2 class='identificadorCard'> ".$fila['nombreTarjeta']."</h2>";
            echo "<p> Equipo: ".$fila['equipo']."</p>";
            echo "<p> Año: ".$fila['anio']."</p>";
            echo "<p> Marca: ".$fila['marca']."</p>";
            echo "<a href='#intercambioTarjetas'><button id='btnIntercambio' class='btnIntercambio'>Intercambiar</button></a>";
            echo "</div>";
            echo "</div>";
        }
    }else{
        echo "<p style='font-weight:400;  color: red; margin-top:10px; text-align:'center';>No tiene ninguna tarjeta por el momento, puede agregar sus tarjetas en la parte de arriba.</p>";
    }
}


function getImage($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);

    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $imagenCarta = $card['imagen'];
        }
    }
    return $imagenCarta;
}

function getRubro($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
 
    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $rubroCarta = $card['rubro'];
        }
    }
    return $rubroCarta;
}

function getSubColeccion($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $subColeccionCarta = $card['subcoleccion'];
        }
    }
    return $subColeccionCarta;
}

function getNombreCard($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);

    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $nombreTarjeta = $card['nombreTarjeta'];
        }
    }
    return $nombreTarjeta;
}

function getMarca($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);

    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $marcaTarjeta = $card['marca'];
        }
    }
    return $marcaTarjeta;
}

function getColeccion($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);

    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $coleccionTarjeta = $card['coleccion'];
        }
    }
    return $coleccionTarjeta;
}

function getAnio($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $anioTarjeta = $card['anio'];
        }
    }
    return $anioTarjeta;
}

function getEquipo($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach ($package as $card){ 
            $equipoTarjeta = $card['equipo'];
        }
    }
    return $equipoTarjeta;
}

function userObtained($username){
    $userTable = new functions();
    return $exactUser = $userTable->usuarios($username);
}

function cargarIDCard($idUsuario){
    $functions = new functions();
    $filas = $functions->cargarTarjetas($idUsuario);
    if(is_object($filas) || is_array($filas)){
        foreach ($filas as $fila){ 
            $idTarjeta = $fila['idTarjeta'];
        }
    }
    return $idTarjeta;
}




//Recopilar informacion de la carta
function storeCard($idUsuario){
    $functions = new functions();
    $filas = $functions->cargarTarjetas($idUsuario);
    $storingArrayIDCard = [];
    if(is_object($filas) || is_array($filas)){
        foreach ($filas as $fila){ 
            $storingArrayIDCard[] = $fila['idTarjeta'];
        }
    }
    $tamanio = count($storingArrayIDCard);
    for($i = 0; $i < $tamanio; $i++){
        echo $storingArrayIDCard[$i];
    }
}


function loadSpecificCard($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach($package as $card){
            echo "<img class='imagenSpecifica' src='../fotos/".$card['imagen']."'>";
        }
    }
}
function loadSpecificName($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach($package as $card){
            echo "<p class='cardNameModal'>".$card['nombreTarjeta']."</p>";
        }
    }
}
function loadSpecificEquipo($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach($package as $card){
            echo "<p class='cardNameModal'>".$card['equipo']."</p>";
        }
    }
}
function loadSpecificYear($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    if(is_object($package) || is_array($package)){
        foreach($package as $card){
            echo "<p class='cardNameModal'>".$card['anio']."</p>";
        }
    }
}

function eliminarTarjeta($idTarjeta){
    $order = new functions();
    $package = $order->tarjetaEspecifica($idTarjeta);
    return $package;
}