<?php

require_once '../Modelo/conexion.php';
require_once '../Modelo/funciones.php';

function login($username){
    $userClass = new Functions();
    session_start();
    $uid = $userClass->userLogin($username);
    if($uid)
    {
        $url = URL_FILE.'Vista/intercambios.php';
        header("Location: $url");  // Page redirecting to intercambios.php
    }   
    else
    {
        return "Revisa tu nombre de usuario registrado.";
    }
}
?>