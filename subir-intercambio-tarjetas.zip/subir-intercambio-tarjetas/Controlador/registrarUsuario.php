<?php

    require_once '../Modelo/conexion.php';
    require_once '../Modelo/funciones.php';

    function registrarUsuario($firstName, $lastName, $password, $email){
        $objectClass = new functions();
        $registerFunction = $objectClass->userRegistration();
        
    }