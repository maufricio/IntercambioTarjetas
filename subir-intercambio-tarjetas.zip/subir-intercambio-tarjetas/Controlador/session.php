<?php
    function session(){
        session_start();
        if(!empty($_SESSION['id_Usuario']))
            return $_SESSION['id_Usuario'];
        if(empty($session_uid))
        {
            $url=URL_FILE.'Vista/usuario.php';
            header("Location: $url");
        }
    }
?>