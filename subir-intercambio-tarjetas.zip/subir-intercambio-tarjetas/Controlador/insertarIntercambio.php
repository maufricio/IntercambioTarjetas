<?php
require_once '../Modelo/conexion.php';
require_once '../Modelo/funciones.php';
require_once 'cargarUsuario.php';

function transferCard($idTarjeta, $username){
    $functions = new functions();
    $message = $functions->set_Tarjetas(obtenerIdUsuario($username), getRubro($idTarjeta), getSubColeccion($idTarjeta), getNombreCard($idTarjeta), getMarca($idTarjeta), getColeccion($idTarjeta), getAnio($idTarjeta), getEquipo($idTarjeta), getImage($idTarjeta));
    return $message;
}