<?php
require_once '../Modelo/conexion.php';
require_once '../Modelo/funciones.php';
require_once 'cargarUsuario.php';
require_once 'insertarIntercambio.php';
require_once 'cargarTarjetas.php';
require_once '../Vista/intercambios.php';

    if(isset($_POST['btnIntercambioModal'])){
        if(strlen(trim($_POST['txtNombreDestino'])) > 0 && is_string($_POST['txtNombreDestino'])){
            @$nombreDestinatarioTarjeta = $_POST['txtNombreDestino'];
            echo transferCard($numeroTarjeta, $nombreDestinatarioTarjeta);
            $consultas = new functions();
            echo $mensaje = $consultas->eliminarTarjeta($numeroTarjeta);
            echo "<script> window.location='http://localhost/BeondPlatform/subir-intercambio-tarjetas/Vista/intercambios.php'; alert('Intercambiado con éxito'); </script>";
        }else{
            echo "<script>alert('Ingresa correctamente el nombre de tu intercambiario.');window.location='http://localhost/BeondPlatform/subir-intercambio-tarjetas/Vista/intercambios.php';</script>";
        }
    }
?>
 
 