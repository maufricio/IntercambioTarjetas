<?php
    require_once 'cargarTarjetas.php';
    require_once '../Modelo/funciones.php';
    function obtenerUsuario($username){
        $exampleUser = "";
        $userTable = new functions();
        $exactUser = $userTable->usuarios($username);
        if(is_object($exactUser) || is_array($exactUser)){
            foreach($exactUser as $ourUser){
                $exampleUser = $ourUser['id_Usuario'];
            }
        }
        return $exampleUser;
    }

    function obtenerIdUsuario($username){
            $userClass = new functions();
            $uid = $userClass->getIdUsuario($username);
            if($uid)
            {
                return $uid;
            }   
            else
            {
                echo "<script>alert('Nombre de intercambiario no encontrado!');window.location='http://localhost/BeondPlatform/subir-intercambio-tarjetas/Vista/intercambios.php';</script>";
                return false;
            }
    }


    function obtenerNombreUsuario($username){
        $exampleUser = "";
        $userTable = new functions();
        $exactUser = $userTable->usuarios($username);
        if(is_object($exactUser) || is_array($exactUser)){
            foreach($exactUser as $ourUser){
                $exampleUser = $ourUser['nombreUsuario'];
            }
        }
        return $exampleUser;
    }

    function obtenerUsuarioAll($idUsuario){
        $exampleUser = "";
        $userTable = new functions();
        $exactUser = $userTable->usuariosAll();
        if(is_object($exactUser) || is_array($exactUser)){
            foreach($exactUser as $ourUser){
                echo "<div id='listaUsuariosModal'>";
                echo "<img src='../Imagenes/usuarioOuttaSeries.png' class='imgUsuarioIntercambiar'/>";
                echo "<p>".$ourUser['nombreUsuario']." ".$ourUser['apellidoUsuario']."</p>";
                echo "</div>";
            }
        }
    }