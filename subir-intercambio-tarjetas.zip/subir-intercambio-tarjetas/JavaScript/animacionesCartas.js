
document.getElementById('imagen-formulario').onchange = function(e){
    let reader = new FileReader();
    //Leer como url la imagen que se selecciona
    //target hace referencia al objeto al cual se esta trabajando, es decir input tipo file
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = function(){
        let preview = document.getElementById('imagePreview');
        image = document.createElement('img');
        image.style.cssText = "width:100%;height:100%;";
        image.src=reader.result;    
        preview.innerHTML = '';
        preview.append(image);
    }
}


const contenedorTarjetas = document.getElementById('identificadorCard');
contenedorTarjetas.addEventListener("load", function(){
    alert(contenedorTarjetas);
}, false);




